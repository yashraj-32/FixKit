const ENDPOINT = 'https://openrouter.ai/api/v1/chat/completions';

export type ContentPart = { type: 'text'; text: string } | { type: 'image_url'; image_url: { url: string } };
export interface ChatMessage {
  role: 'system' | 'user' | 'assistant';
  content: string | ContentPart[];
}

export class OpenRouterError extends Error {
  constructor(message: string, public code: 'auth' | 'rate_limit' | 'timeout' | 'network' | 'model' | 'credits' | 'server' | 'bad_request') {
    super(message);
  }
}

export interface ChatOptions {
  apiKey: string;
  model: string;
  messages: ChatMessage[];
  timeoutMs?: number;
  json?: boolean;
  maxTokens?: number;
}

export async function chat(opts: ChatOptions): Promise<string> {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), opts.timeoutMs ?? 90_000);
  let res: Response;
  try {
    res = await fetch(ENDPOINT, {
      method: 'POST',
      signal: controller.signal,
      headers: {
        Authorization: `Bearer ${opts.apiKey}`,
        'Content-Type': 'application/json',
        'HTTP-Referer': 'https://github.com/fixkit/fixkit',
        'X-Title': 'FixKit Troubleshooter'
      },
      body: JSON.stringify({
        model: opts.model,
        messages: opts.messages,
        temperature: 0.2,
        max_tokens: opts.maxTokens ?? 3000,
        ...(opts.json ? { response_format: { type: 'json_object' } } : {})
      })
    });
  } catch (e: any) {
    if (e?.name === 'AbortError') throw new OpenRouterError('The AI service took too long to respond. Please try again.', 'timeout');
    throw new OpenRouterError('Could not reach OpenRouter. Check your internet connection.', 'network');
  } finally {
    clearTimeout(timer);
  }

  const body: any = await res.json().catch(() => ({}));
  if (!res.ok || body.error) {
    const status = res.ok ? body.error?.code : res.status;
    const detail: string = body.error?.message ?? res.statusText ?? '';
    throw mapError(Number(status), detail, opts.model);
  }
  const content = body.choices?.[0]?.message?.content;
  if (typeof content !== 'string' || !content.trim()) {
    throw new OpenRouterError('The model returned an empty response. Try again or pick a different model in Settings.', 'server');
  }
  return content;
}

function mapError(status: number, detail: string, model: string): OpenRouterError {
  const d = detail.toLowerCase();
  if (status === 401 || d.includes('api key') || d.includes('no auth')) {
    return new OpenRouterError('Your OpenRouter API key was rejected. Re-enter it in Settings.', 'auth');
  }
  if (status === 402) return new OpenRouterError('Your OpenRouter account is out of credits for this model.', 'credits');
  if (status === 429) return new OpenRouterError('Rate limit reached. Wait a moment and try again.', 'rate_limit');
  if (status === 404 || d.includes('not a valid model') || d.includes('no endpoints') || d.includes('model')) {
    if (d.includes('image') || d.includes('vision')) {
      return new OpenRouterError(`The model "${model}" cannot read images. Choose a vision-capable model in Settings.`, 'model');
    }
    return new OpenRouterError(`The model "${model}" is unavailable. Choose another model in Settings.`, 'model');
  }
  if (status === 408 || status === 504) return new OpenRouterError('The AI provider timed out. Please try again.', 'timeout');
  if (status >= 500) return new OpenRouterError('The AI provider had a temporary error. Please try again.', 'server');
  return new OpenRouterError(`OpenRouter error: ${detail || status}`, 'bad_request');
}

export async function testKey(apiKey: string, model: string): Promise<{ ok: boolean; message: string }> {
  try {
    const keyRes = await fetch('https://openrouter.ai/api/v1/key', { headers: { Authorization: `Bearer ${apiKey}` } });
    if (keyRes.status === 401) return { ok: false, message: 'API key was rejected by OpenRouter.' };
    await chat({ apiKey, model, messages: [{ role: 'user', content: 'Reply with the single word: ok' }], maxTokens: 5, timeoutMs: 30_000 });
    return { ok: true, message: `Connected. Model "${model}" responded.` };
  } catch (e: any) {
    return { ok: false, message: e?.message ?? String(e) };
  }
}
