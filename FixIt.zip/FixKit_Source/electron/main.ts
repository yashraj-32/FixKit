import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import { app, BrowserWindow, ipcMain, nativeTheme, shell } from 'electron';
import { Store } from './db';
import { KnowledgeBase } from './kb';
import { TroubleshootingEngine } from './engine';
import { SecretStore } from './secrets';
import { testKey, OpenRouterError } from './openrouter';
import type { Attachment, Diagnosis, Settings } from './shared';

const DEFAULT_MODEL = 'google/gemini-2.5-flash';
const MAX_IMAGE_BYTES = 8 * 1024 * 1024;
const IMAGE_RE = /^data:image\/(png|jpe?g);base64,([A-Za-z0-9+/=]+)$/;

const dataDir = app.getPath('userData');
const imagesDir = path.join(dataDir, 'screenshots');
const userKbDir = path.join(dataDir, 'knowledge');
const bundledKbDir = app.isPackaged ? path.join(process.resourcesPath, 'knowledge') : path.join(__dirname, '..', 'knowledge');

const store = new Store(dataDir);
const secrets = new SecretStore(dataDir);
const kb = new KnowledgeBase([bundledKbDir, userKbDir]);
const engine = new TroubleshootingEngine(kb);

let win: BrowserWindow | null = null;

function settings(): Settings {
  return {
    model: store.getPref('model') ?? DEFAULT_MODEL,
    visionModel: store.getPref('visionModel') ?? DEFAULT_MODEL,
    theme: (store.getPref('theme') as Settings['theme']) ?? 'dark',
    hasApiKey: !!secrets.get(),
    apiKeyHint: secrets.hint(),
    secureStorage: secrets.available()
  };
}

function saveImage(a: Attachment): string {
  const m = IMAGE_RE.exec(a.dataUrl);
  if (!m) throw new Error('Only PNG and JPG screenshots are supported.');
  const buf = Buffer.from(m[2], 'base64');
  if (buf.length > MAX_IMAGE_BYTES) throw new Error('Screenshot is larger than 8 MB. Please crop it or save it as JPG.');
  const name = `${crypto.randomUUID()}.${m[1] === 'png' ? 'png' : 'jpg'}`;
  fs.writeFileSync(path.join(imagesDir, name), buf);
  return name;
}

function loadImage(name: string): string | null {
  if (!/^[0-9a-f-]+\.(png|jpg)$/.test(name)) return null; // no path traversal
  const file = path.join(imagesDir, name);
  if (!fs.existsSync(file)) return null;
  const mime = name.endsWith('.png') ? 'image/png' : 'image/jpeg';
  return `data:${mime};base64,${fs.readFileSync(file).toString('base64')}`;
}

function titleFrom(text: string, d: Diagnosis | null): string {
  if (d?.title && d.kind === 'diagnosis') return d.title.slice(0, 80);
  const t = text.trim().replace(/\s+/g, ' ');
  return t ? (t.length > 60 ? t.slice(0, 57) + '…' : t) : 'Screenshot analysis';
}

function saveDiagnosisToKnowledgeBase(problem: string, diagnosis: Diagnosis): void {
  if (diagnosis.kind !== 'diagnosis' || !diagnosis.title || !diagnosis.steps?.length) return;
  const normalizedProblem = problem.trim().replace(/\s+/g, ' ');
  if (normalizedProblem.length < 8) return;

  const id = `ai-${crypto.createHash('sha256').update(`${normalizedProblem.toLowerCase()}\n${diagnosis.title.toLowerCase()}`).digest('hex').slice(0, 20)}`;
  const file = path.join(userKbDir, 'generated.json');
  let records: any[] = [];
  try {
    if (fs.existsSync(file)) {
      const data = JSON.parse(fs.readFileSync(file, 'utf8'));
      records = Array.isArray(data) ? data : Array.isArray(data.records) ? data.records : [];
    }
  } catch (e) {
    console.error('[kb] could not read generated records:', e);
    return; // Preserve a damaged file for recovery instead of overwriting it.
  }
  if (records.some((record) => record?.id === id)) return;

  records.push({
    id,
    software: 'Visual Studio Code / C++ toolchain',
    environment: 'Windows',
    category: diagnosis.category ?? 'AI-generated',
    title: diagnosis.title.slice(0, 160),
    error: normalizedProblem.slice(0, 2000),
    error_patterns: [],
    keywords: [...new Set(`${normalizedProblem} ${diagnosis.title} ${diagnosis.category ?? ''}`.toLowerCase().match(/[a-z0-9_.#+-]{2,}/g) ?? [])].slice(0, 40),
    symptoms: [diagnosis.problem ?? normalizedProblem].filter(Boolean).map((value) => value.slice(0, 1000)),
    possible_causes: diagnosis.cause ? [diagnosis.cause.slice(0, 1000)] : [],
    diagnostic_questions: diagnosis.question ? [diagnosis.question.slice(0, 500)] : [],
    solution: diagnosis.steps.slice(0, 12).map((step) => ({
      title: (step.title || 'Suggested step').slice(0, 160),
      detail: [step.location, step.action, step.expected ? `Expected: ${step.expected}` : ''].filter(Boolean).join('\n').slice(0, 2000),
      ...(step.code?.content ? { code: step.code.content.slice(0, 4000), ...(step.code.where ? { shell: step.code.where } : {}), ...(step.code.file ? { file: step.code.file } : {}) } : {})
    })),
    expected_result: diagnosis.verification?.slice(0, 1000) ?? 'See the suggested verification steps.',
    verification: diagnosis.verification?.slice(0, 1000) ?? '',
    alternatives: diagnosis.if_fails ? [diagnosis.if_fails.slice(0, 1000)] : [],
    sources: [],
    last_reviewed: new Date().toISOString().slice(0, 10)
  });
  fs.writeFileSync(file, JSON.stringify({ records }, null, 2), 'utf8');
  kb.load();
}

function registerIpc() {
  ipcMain.handle('sessions:list', () => store.listSessions());
  ipcMain.handle('sessions:get', (_e, id: number) => {
    const session = store.getSession(id);
    return session ? { session, messages: store.getMessages(id) } : null;
  });
  ipcMain.handle('sessions:create', (_e, title?: string) => store.createSession(title || 'New session'));
  ipcMain.handle('sessions:rename', (_e, id: number, title: string) => store.updateSession(id, { title: String(title).slice(0, 120) }));
  ipcMain.handle('sessions:setStatus', (_e, id: number, status: string) => {
    if (!['open', 'resolved', 'unresolved'].includes(status)) throw new Error('Invalid status');
    return store.updateSession(id, { status: status as any });
  });
  ipcMain.handle('sessions:remove', (_e, id: number) => {
    for (const img of store.deleteSession(id)) fs.rmSync(path.join(imagesDir, img), { force: true });
  });

  ipcMain.handle('chat:send', async (_e, sessionId: number | null, text: string, attachments: Attachment[]) => {
    text = String(text ?? '').slice(0, 20_000);
    attachments = (attachments ?? []).slice(0, 4);
    const imageNames = attachments.map(saveImage);
    const isNew = sessionId == null;
    let session = isNew ? store.createSession(titleFrom(text, null)) : store.getSession(sessionId!);
    if (!session) throw new Error('Session not found');

    const history = store.getMessages(session.id);
    const user = store.addMessage({ session_id: session.id, role: 'user', content: text, images: imageNames, diagnosis: null, meta: null });

    const s = settings();
    let assistant;
    try {
      const out = await engine.run(
        { history, text, images: attachments.map((a) => a.dataUrl), historyImages: loadImage },
        { apiKey: secrets.get(), model: s.model, visionModel: s.visionModel }
      );
      if (!out.offline) saveDiagnosisToKnowledgeBase(text, out.diagnosis);
      assistant = store.addMessage({
        session_id: session.id,
        role: 'assistant',
        content: out.diagnosis.text ?? out.diagnosis.problem ?? out.diagnosis.question ?? '',
        diagnosis: out.diagnosis,
        images: [],
        meta: { matchKind: out.matchKind, kbIds: out.kbIds, model: out.model, offline: out.offline }
      });
      const patch: Parameters<Store['updateSession']>[1] = {};
      if (out.category) patch.category = out.category;
      if (isNew || history.length === 0) patch.title = titleFrom(text, out.diagnosis);
      session = store.updateSession(session.id, patch);
    } catch (e: any) {
      const message = e instanceof OpenRouterError ? e.message : `Something went wrong: ${e?.message ?? e}`;
      assistant = store.addMessage({
        session_id: session.id,
        role: 'system',
        content: message,
        diagnosis: null,
        images: [],
        meta: { error: e?.code ?? 'unknown' }
      });
    }
    return { user, assistant, session };
  });

  ipcMain.handle('kb:list', () => kb.records);
  ipcMain.handle('kb:search', (_e, q: string) => kb.search(String(q), 20));
  ipcMain.handle('kb:reload', () => kb.load());
  ipcMain.handle('kb:openFolder', () => shell.openPath(userKbDir));

  ipcMain.handle('settings:get', () => settings());
  ipcMain.handle('settings:update', (_e, patch: Partial<Settings>) => {
    for (const key of ['model', 'visionModel', 'theme'] as const) {
      const v = patch[key];
      if (typeof v === 'string' && v.trim()) store.setPref(key, v.trim());
    }
    if (patch.theme) nativeTheme.themeSource = patch.theme;
    return settings();
  });
  ipcMain.handle('settings:setApiKey', (_e, key: string) => {
    if (typeof key !== 'string' || key.trim().length < 10) throw new Error('That does not look like an OpenRouter API key.');
    secrets.set(key);
    return settings();
  });
  ipcMain.handle('settings:clearApiKey', () => {
    secrets.clear();
    return settings();
  });
  ipcMain.handle('settings:test', async () => {
    const key = secrets.get();
    if (!key) return { ok: false, message: 'No API key saved yet.' };
    return testKey(key, settings().model);
  });

  ipcMain.handle('images:load', (_e, name: string) => loadImage(String(name)));
  ipcMain.handle('app:info', () => ({
    version: app.getVersion(),
    kbCount: kb.records.length,
    kbCategories: kb.categories(),
    kbPaths: kb.sources,
    dataDir
  }));
  ipcMain.handle('app:openExternal', (_e, url: string) => {
    if (/^https:\/\//.test(url)) return shell.openExternal(url);
  });
}

function createWindow() {
  win = new BrowserWindow({
    width: 1320,
    height: 860,
    minWidth: 960,
    minHeight: 640,
    backgroundColor: '#0e0f11',
    title: 'FixKit',
    autoHideMenuBar: true,
    webPreferences: {
      preload: path.join(__dirname, 'preload.js'),
      contextIsolation: true,
      nodeIntegration: false,
      sandbox: true
    }
  });
  // Links open in the system browser, never inside the app.
  win.webContents.setWindowOpenHandler(({ url }) => {
    if (url.startsWith('https://')) shell.openExternal(url);
    return { action: 'deny' };
  });
  win.webContents.on('will-navigate', (e, url) => {
    if (!url.startsWith(process.env.VITE_DEV_SERVER_URL ?? 'file://')) e.preventDefault();
  });
  // Dev aid: FIXKIT_SCREENSHOT=out.png captures the first rendered frame and quits.
  const shot = process.env.FIXKIT_SCREENSHOT;
  if (shot) {
    win.webContents.on('did-finish-load', () =>
      setTimeout(async () => {
        if (process.env.FIXKIT_SCRIPT) await win!.webContents.executeJavaScript(process.env.FIXKIT_SCRIPT);
        setTimeout(async () => {
          fs.writeFileSync(shot, (await win!.webContents.capturePage()).toPNG());
          app.quit();
        }, Number(process.env.FIXKIT_WAIT ?? 800));
      }, 800)
    );
  }
  if (process.env.VITE_DEV_SERVER_URL) win.loadURL(process.env.VITE_DEV_SERVER_URL);
  else win.loadFile(path.join(__dirname, '..', 'dist', 'index.html'));
}

app.whenReady().then(async () => {
  fs.mkdirSync(imagesDir, { recursive: true });
  fs.mkdirSync(userKbDir, { recursive: true });
  const wasm = path.join(path.dirname(require.resolve('sql.js')), 'sql-wasm.wasm').replace('app.asar', 'app.asar.unpacked');
  await store.open(wasm);
  kb.load();
  nativeTheme.themeSource = settings().theme;
  registerIpc();
  createWindow();
});

app.on('window-all-closed', () => app.quit());
