import fs from 'node:fs';
import path from 'node:path';
import type { KbMatch, KbRecord, MatchKind } from './shared';

const STOP = new Set(
  'a an the is are was were be been my me i it its to of in on for and or but not with this that when what why how do does did can cant cannot dont doesnt im ive have has had so just at from by as vs code c++ cpp please help error issue problem working work works'.split(' ')
);

export function tokenize(text: string): string[] {
  return text
    .toLowerCase()
    .replace(/c\+\+/g, 'cpp')
    .replace(/g\+\+/g, 'gpp')
    .replace(/[^a-z0-9_.#\-]+/g, ' ')
    .split(/\s+/)
    .map((t) => t.replace(/^[.\-]+|[.\-]+$/g, ''))
    .filter((t) => t.length > 1 && !STOP.has(t));
}

function normalize(text: string): string {
  return text.toLowerCase().replace(/[‘’'"`]/g, '').replace(/\s+/g, ' ').trim();
}

interface Indexed {
  record: KbRecord;
  fieldTokens: { tokens: string[]; weight: number }[];
  patterns: string[];
  length: number;
}

/**
 * Hybrid lexical retrieval:
 *  - exact / near-exact error-message matching (highest signal)
 *  - BM25 over weighted fields (title, keywords, symptoms, causes, category)
 *  - phrase matching on keywords
 */
export class KnowledgeBase {
  records: KbRecord[] = [];
  sources: string[] = [];
  private index: Indexed[] = [];
  private df = new Map<string, number>();
  private avgLen = 1;

  constructor(private dirs: string[]) {}

  load(): number {
    const byId = new Map<string, KbRecord>();
    this.sources = [];
    // Later directories override earlier ones by id (user folder overrides bundled data).
    for (const dir of this.dirs) {
      if (!fs.existsSync(dir)) continue;
      for (const f of fs.readdirSync(dir).filter((f) => f.endsWith('.json')).sort()) {
        const full = path.join(dir, f);
        try {
          const data = JSON.parse(fs.readFileSync(full, 'utf8'));
          const list: KbRecord[] = Array.isArray(data) ? data : data.records ?? [];
          for (const r of list) if (validRecord(r)) byId.set(r.id, r);
          this.sources.push(full);
        } catch (e) {
          console.error(`[kb] failed to load ${full}:`, e);
        }
      }
    }
    this.setRecords([...byId.values()]);
    return this.records.length;
  }

  setRecords(records: KbRecord[]) {
    this.records = records;
    this.df.clear();
    this.index = records.map((r) => {
      const fieldTokens = [
        { tokens: tokenize(r.title), weight: 2.5 },
        { tokens: tokenize(r.error), weight: 3 },
        { tokens: tokenize(r.keywords.join(' ')), weight: 2.5 },
        { tokens: tokenize(r.symptoms.join(' ')), weight: 1.5 },
        { tokens: tokenize(r.possible_causes.join(' ')), weight: 0.8 },
        { tokens: tokenize(r.category), weight: 1 }
      ];
      const uniq = new Set(fieldTokens.flatMap((f) => f.tokens));
      uniq.forEach((t) => this.df.set(t, (this.df.get(t) ?? 0) + 1));
      return {
        record: r,
        fieldTokens,
        patterns: [r.error, ...(r.error_patterns ?? [])].map(normalize).filter((p) => p.length >= 6),
        length: fieldTokens.reduce((n, f) => n + f.tokens.length, 0)
      };
    });
    this.avgLen = this.index.reduce((n, i) => n + i.length, 0) / Math.max(1, this.index.length);
  }

  categories(): string[] {
    return [...new Set(this.records.map((r) => r.category))].sort();
  }

  search(query: string, limit = 5): KbMatch[] {
    const q = normalize(query);
    const qTokens = [...new Set(tokenize(query))];
    if (!qTokens.length && !q) return [];
    const N = this.index.length;
    const k1 = 1.2;
    const b = 0.75;

    const results: KbMatch[] = [];
    for (const item of this.index) {
      const reasons: string[] = [];
      let score = 0;

      for (const p of item.patterns) {
        if (q.includes(p)) {
          score += 12;
          reasons.push(`error text "${p}"`);
          break;
        }
      }

      for (const kw of item.record.keywords) {
        const k = normalize(kw);
        if (k.includes(' ') && q.includes(k)) {
          score += 3;
          reasons.push(`phrase "${kw}"`);
        }
      }

      let bm = 0;
      const matched: string[] = [];
      for (const t of qTokens) {
        const df = this.df.get(t);
        if (!df) continue;
        const idf = Math.log(1 + (N - df + 0.5) / (df + 0.5));
        let tf = 0;
        for (const f of item.fieldTokens) tf += f.tokens.filter((x) => x === t).length * f.weight;
        if (!tf) continue;
        matched.push(t);
        bm += (idf * tf * (k1 + 1)) / (tf + k1 * (1 - b + (b * item.length) / this.avgLen));
      }
      score += bm;
      if (matched.length) reasons.push(`terms: ${matched.slice(0, 6).join(', ')}`);
      if (score > 0) results.push({ record: item.record, score: Math.round(score * 100) / 100, reasons });
    }
    return results.sort((a, b) => b.score - a.score).slice(0, limit);
  }
}

function validRecord(r: any): r is KbRecord {
  return r && typeof r.id === 'string' && typeof r.title === 'string' && Array.isArray(r.keywords) && Array.isArray(r.solution);
}

// ---- classification ----

const IN_SCOPE = /\b(vs ?code|visual studio code|code\.exe|c\+\+|cpp|g\+\+|gcc|gdb|clang|mingw|msys2?|ucrt64|compile|compiler|linker|ld\.exe|collect2|intellisense|includepath|include path|tasks\.json|launch\.json|c_cpp_properties|settings\.json|extension|debugger|debug|terminal|powershell|path|environment variable|undefined reference|header|#include|\.exe|build|code runner|cmake|makefile|std::|iostream|main\(|segmentation|workspace)\b/i;
const OUT_SCOPE = /\b(python|pip|java(?!script)|javascript|node\.?js|npm|react|android|iphone|ios|excel|word|photoshop|wifi|printer|bluetooth|game|minecraft|steam|netflix|homework|essay|recipe|crypto|stock)\b/i;

const CATEGORY_RULES: [RegExp, string][] = [
  [/undefined reference|collect2|ld returned|ld\.exe|linker|multiple definition|winmain/i, 'Linker Errors'],
  [/gdb|debugger|launch\.json|breakpoint|miDebuggerPath|debug/i, 'Debugging'],
  [/tasks\.json|build task|preLaunchTask|ctrl\+shift\+b/i, 'Build Tasks'],
  [/intellisense|squiggl|red underline|c_cpp_properties|includepath|cannot open source file/i, 'IntelliSense'],
  [/not recognized|command not found|path|environment variable/i, 'PATH Issues'],
  [/msys2|pacman|ucrt64|mingw64 shell/i, 'MSYS2'],
  [/mingw|install.*(compiler|gcc|g\+\+)/i, 'Compiler Installation'],
  [/c\+\+17|c\+\+20|-std=|structured binding|std::optional|std::format|ranges/i, 'C++ Standard Configuration'],
  [/no such file or directory|fatal error:.*\.h|#include/i, 'Include Directories'],
  [/extension|marketplace/i, 'C++ Extensions'],
  [/terminal|powershell|cmd\.exe|execution polic/i, 'Terminal Configuration'],
  [/workspace|folder|\.vscode/i, 'Workspace Configuration'],
  [/error:|expected|was not declared|compile|compil/i, 'Compilation Errors']
];

export function classify(text: string): string | null {
  for (const [re, cat] of CATEGORY_RULES) if (re.test(text)) return cat;
  return null;
}

export function inScope(text: string, hasImage: boolean): boolean {
  if (IN_SCOPE.test(text)) return true;
  if (OUT_SCOPE.test(text)) return false;
  // Short or vague messages (and screenshots) get the benefit of the doubt; the model asks follow-ups.
  return hasImage || text.trim().split(/\s+/).length < 12;
}

/** Decide how confident retrieval is, to steer how the model should answer. */
export function matchKind(matches: KbMatch[], text: string, hasImage: boolean): MatchKind {
  if (!inScope(text, hasImage) && (matches[0]?.score ?? 0) < 6) return 'out_of_scope';
  const top = matches[0];
  if (!top || top.score < 5) return 'unknown';
  const second = matches[1];
  if (second && second.score >= top.score * 0.75) return 'known_multiple';
  return 'known_verified';
}
