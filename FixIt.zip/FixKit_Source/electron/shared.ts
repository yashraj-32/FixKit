// Types shared between the Electron main process and the React renderer.
// Must not import any Node or Electron modules.

export interface KbStep {
  title: string;
  detail: string;
  code?: string;
  shell?: string; // e.g. "VS Code terminal (PowerShell)", "MSYS2 UCRT64"
  file?: string; // e.g. ".vscode/tasks.json"
}

export interface KbRecord {
  id: string;
  software: string;
  software_version?: string;
  environment: string;
  category: string;
  title: string;
  error: string;
  error_patterns?: string[];
  keywords: string[];
  symptoms: string[];
  possible_causes: string[];
  diagnostic_questions: string[];
  solution: KbStep[];
  expected_result: string;
  verification: string;
  alternatives: string[];
  sources: { title: string; url: string }[];
  /** Date the record was last reviewed against the listed sources. Not a claim of lab verification. */
  last_reviewed: string;
}

export interface KbMatch {
  record: KbRecord;
  score: number;
  reasons: string[];
}

export type MatchKind = 'known_verified' | 'known_multiple' | 'unknown' | 'out_of_scope';

export interface CodeBlock {
  language: string;
  content: string;
  /** Where to run / paste it, e.g. "VS Code integrated terminal (PowerShell)" */
  where?: string;
  /** For file edits: path of the file */
  file?: string;
  /** For file edits: replace the whole file or merge into existing content */
  mode?: 'run' | 'replace' | 'merge';
  explanation?: string;
}

export interface DiagnosisStep {
  title: string;
  location?: string;
  action: string;
  code?: CodeBlock;
  expected?: string;
}

export interface Diagnosis {
  kind: 'diagnosis' | 'question' | 'out_of_scope' | 'text';
  category?: string;
  title?: string;
  problem?: string;
  cause?: string;
  confidence?: 'high' | 'medium' | 'low';
  basis?: 'knowledge_base' | 'general_knowledge' | 'mixed';
  kb_ids?: string[];
  question?: string;
  steps?: DiagnosisStep[];
  verification?: string;
  if_fails?: string;
  warnings?: string[];
  screenshot_findings?: {
    errors?: string[];
    paths?: string[];
    tools?: string[];
    notes?: string;
  };
  /** Free text, used when kind === 'text' or as a short lead-in */
  text?: string;
}

export interface Message {
  id: number;
  session_id: number;
  role: 'user' | 'assistant' | 'system';
  content: string;
  diagnosis?: Diagnosis | null;
  images: string[];
  meta?: { matchKind?: MatchKind; kbIds?: string[]; model?: string; offline?: boolean; error?: string } | null;
  created_at: string;
}

export interface Session {
  id: number;
  title: string;
  category: string | null;
  status: 'open' | 'resolved' | 'unresolved';
  created_at: string;
  updated_at: string;
  message_count?: number;
}

export interface Settings {
  model: string;
  visionModel: string;
  theme: 'dark' | 'light' | 'system';
  hasApiKey: boolean;
  apiKeyHint: string | null; // e.g. "sk-or-…a1b2"
  secureStorage: boolean;
}

export interface AppInfo {
  version: string;
  kbCount: number;
  kbCategories: string[];
  kbPaths: string[];
  dataDir: string;
}

export interface Attachment {
  name: string;
  dataUrl: string;
}

export interface SendResult {
  user: Message;
  assistant: Message;
  session: Session;
}

export interface FixKitApi {
  sessions: {
    list(): Promise<Session[]>;
    get(id: number): Promise<{ session: Session; messages: Message[] } | null>;
    create(title?: string): Promise<Session>;
    rename(id: number, title: string): Promise<Session>;
    setStatus(id: number, status: Session['status']): Promise<Session>;
    remove(id: number): Promise<void>;
  };
  chat: {
    send(sessionId: number | null, text: string, attachments: Attachment[]): Promise<SendResult>;
  };
  kb: {
    list(): Promise<KbRecord[]>;
    search(q: string): Promise<KbMatch[]>;
    reload(): Promise<number>;
    openFolder(): Promise<void>;
  };
  settings: {
    get(): Promise<Settings>;
    update(patch: Partial<Pick<Settings, 'model' | 'visionModel' | 'theme'>>): Promise<Settings>;
    setApiKey(key: string): Promise<Settings>;
    clearApiKey(): Promise<Settings>;
    test(): Promise<{ ok: boolean; message: string }>;
  };
  images: {
    load(name: string): Promise<string | null>;
  };
  app: {
    info(): Promise<AppInfo>;
    openExternal(url: string): Promise<void>;
  };
}
