import fs from 'node:fs';
import path from 'node:path';
import { safeStorage } from 'electron';

/**
 * Stores the OpenRouter key encrypted with Electron safeStorage, which uses
 * Windows DPAPI (tied to the current Windows user account). The key never
 * goes into SQLite and is never sent to the renderer.
 */
export class SecretStore {
  private file: string;

  constructor(dataDir: string) {
    this.file = path.join(dataDir, 'credentials.bin');
  }

  available(): boolean {
    return safeStorage.isEncryptionAvailable();
  }

  get(): string | null {
    // Environment variable wins, useful for development.
    if (process.env.OPENROUTER_API_KEY) return process.env.OPENROUTER_API_KEY;
    if (!fs.existsSync(this.file) || !this.available()) return null;
    try {
      return safeStorage.decryptString(fs.readFileSync(this.file));
    } catch {
      return null;
    }
  }

  set(key: string) {
    if (!this.available()) throw new Error('Secure storage is not available on this system, so the key cannot be saved safely.');
    fs.writeFileSync(this.file, safeStorage.encryptString(key.trim()));
  }

  clear() {
    if (fs.existsSync(this.file)) fs.rmSync(this.file);
  }

  hint(): string | null {
    const k = this.get();
    return k ? `${k.slice(0, 6)}…${k.slice(-4)}` : null;
  }
}
