import { contextBridge, ipcRenderer } from 'electron';
import type { FixKitApi } from './shared';

const call = (channel: string) => (...args: unknown[]) => ipcRenderer.invoke(channel, ...args);

const api: FixKitApi = {
  sessions: {
    list: call('sessions:list'),
    get: call('sessions:get'),
    create: call('sessions:create'),
    rename: call('sessions:rename'),
    setStatus: call('sessions:setStatus'),
    remove: call('sessions:remove')
  } as FixKitApi['sessions'],
  chat: { send: call('chat:send') } as FixKitApi['chat'],
  kb: {
    list: call('kb:list'),
    search: call('kb:search'),
    reload: call('kb:reload'),
    openFolder: call('kb:openFolder')
  } as FixKitApi['kb'],
  settings: {
    get: call('settings:get'),
    update: call('settings:update'),
    setApiKey: call('settings:setApiKey'),
    clearApiKey: call('settings:clearApiKey'),
    test: call('settings:test')
  } as FixKitApi['settings'],
  images: { load: call('images:load') } as FixKitApi['images'],
  app: { info: call('app:info'), openExternal: call('app:openExternal') } as FixKitApi['app']
};

contextBridge.exposeInMainWorld('fixkit', api);
