import fs from 'node:fs';
import path from 'node:path';
import initSqlJs, { Database, SqlValue } from 'sql.js';
import type { Diagnosis, Message, Session } from './shared';

// Ordered, append-only migrations. Never edit a shipped migration; add a new one.
const MIGRATIONS: string[] = [
  `CREATE TABLE sessions (
     id INTEGER PRIMARY KEY AUTOINCREMENT,
     title TEXT NOT NULL,
     category TEXT,
     status TEXT NOT NULL DEFAULT 'open',
     created_at TEXT NOT NULL,
     updated_at TEXT NOT NULL
   );
   CREATE TABLE messages (
     id INTEGER PRIMARY KEY AUTOINCREMENT,
     session_id INTEGER NOT NULL REFERENCES sessions(id) ON DELETE CASCADE,
     role TEXT NOT NULL,
     content TEXT NOT NULL,
     diagnosis TEXT,
     images TEXT NOT NULL DEFAULT '[]',
     meta TEXT,
     created_at TEXT NOT NULL
   );
   CREATE INDEX idx_messages_session ON messages(session_id);
   CREATE TABLE preferences (
     key TEXT PRIMARY KEY,
     value TEXT NOT NULL
   );`
];

export class Store {
  private db!: Database;
  private file: string;

  constructor(private dataDir: string) {
    this.file = path.join(dataDir, 'fixkit.db');
  }

  async open(wasmPath?: string) {
    const SQL = await initSqlJs(wasmPath ? { locateFile: () => wasmPath } : undefined);
    fs.mkdirSync(this.dataDir, { recursive: true });
    this.db = fs.existsSync(this.file) ? new SQL.Database(fs.readFileSync(this.file)) : new SQL.Database();
    this.db.run('PRAGMA foreign_keys = ON');
    this.migrate();
  }

  private migrate() {
    this.db.run('CREATE TABLE IF NOT EXISTS schema_version (version INTEGER NOT NULL)');
    const row = this.one<{ version: number }>('SELECT version FROM schema_version');
    let version = row?.version ?? 0;
    if (!row) this.db.run('INSERT INTO schema_version (version) VALUES (0)');
    while (version < MIGRATIONS.length) {
      this.db.exec(MIGRATIONS[version]);
      version++;
      this.db.run('UPDATE schema_version SET version = ?', [version]);
    }
    this.persist();
  }

  private persist() {
    const tmp = this.file + '.tmp';
    fs.writeFileSync(tmp, Buffer.from(this.db.export()));
    fs.renameSync(tmp, this.file);
  }

  private all<T>(sql: string, params: SqlValue[] = []): T[] {
    const stmt = this.db.prepare(sql);
    stmt.bind(params);
    const out: T[] = [];
    while (stmt.step()) out.push(stmt.getAsObject() as T);
    stmt.free();
    return out;
  }

  private one<T>(sql: string, params: SqlValue[] = []): T | undefined {
    return this.all<T>(sql, params)[0];
  }

  private lastId(): number {
    return this.one<{ id: number }>('SELECT last_insert_rowid() AS id')!.id;
  }

  // ---- sessions ----
  listSessions(): Session[] {
    return this.all<Session>(
      `SELECT s.*, (SELECT COUNT(*) FROM messages m WHERE m.session_id = s.id) AS message_count
       FROM sessions s ORDER BY s.updated_at DESC`
    );
  }

  getSession(id: number): Session | undefined {
    return this.one<Session>('SELECT * FROM sessions WHERE id = ?', [id]);
  }

  createSession(title: string): Session {
    const now = new Date().toISOString();
    this.db.run('INSERT INTO sessions (title, created_at, updated_at) VALUES (?, ?, ?)', [title, now, now]);
    const id = this.lastId();
    this.persist();
    return this.getSession(id)!;
  }

  updateSession(id: number, patch: Partial<Pick<Session, 'title' | 'category' | 'status'>>): Session {
    const fields = Object.keys(patch) as (keyof typeof patch)[];
    if (fields.length) {
      const sets = fields.map((f) => `${f} = ?`).join(', ');
      this.db.run(`UPDATE sessions SET ${sets}, updated_at = ? WHERE id = ?`, [
        ...fields.map((f) => (patch[f] ?? null) as SqlValue),
        new Date().toISOString(),
        id
      ]);
      this.persist();
    }
    return this.getSession(id)!;
  }

  deleteSession(id: number): string[] {
    const images = this.getMessages(id).flatMap((m) => m.images);
    this.db.run('DELETE FROM messages WHERE session_id = ?', [id]);
    this.db.run('DELETE FROM sessions WHERE id = ?', [id]);
    this.persist();
    return images;
  }

  // ---- messages ----
  getMessages(sessionId: number): Message[] {
    type Row = Omit<Message, 'diagnosis' | 'images' | 'meta'> & { diagnosis: string | null; images: string; meta: string | null };
    return this.all<Row>('SELECT * FROM messages WHERE session_id = ? ORDER BY id', [sessionId]).map((r) => ({
      ...r,
      diagnosis: r.diagnosis ? (JSON.parse(r.diagnosis) as Diagnosis) : null,
      images: JSON.parse(r.images),
      meta: r.meta ? JSON.parse(r.meta) : null
    }));
  }

  addMessage(m: Omit<Message, 'id' | 'created_at'>): Message {
    const now = new Date().toISOString();
    this.db.run(
      'INSERT INTO messages (session_id, role, content, diagnosis, images, meta, created_at) VALUES (?, ?, ?, ?, ?, ?, ?)',
      [
        m.session_id,
        m.role,
        m.content,
        m.diagnosis ? JSON.stringify(m.diagnosis) : null,
        JSON.stringify(m.images),
        m.meta ? JSON.stringify(m.meta) : null,
        now
      ]
    );
    const id = this.lastId();
    this.db.run('UPDATE sessions SET updated_at = ? WHERE id = ?', [now, m.session_id]);
    this.persist();
    return { ...m, id, created_at: now };
  }

  // ---- preferences (never secrets) ----
  getPref(key: string): string | undefined {
    return this.one<{ value: string }>('SELECT value FROM preferences WHERE key = ?', [key])?.value;
  }

  setPref(key: string, value: string) {
    this.db.run('INSERT INTO preferences (key, value) VALUES (?, ?) ON CONFLICT(key) DO UPDATE SET value = excluded.value', [key, value]);
    this.persist();
  }
}
