import { test } from 'node:test';
import assert from 'node:assert/strict';
import path from 'node:path';
import { KnowledgeBase, matchKind, classify } from '../kb';
import { parseDiagnosis } from '../engine';

const kb = new KnowledgeBase([path.join(__dirname, '..', '..', 'knowledge')]);
kb.load();

test('loads at least 50 records with unique ids and sources', () => {
  assert.ok(kb.records.length >= 50);
  assert.equal(new Set(kb.records.map((r) => r.id)).size, kb.records.length);
  for (const r of kb.records) assert.ok(r.sources.length > 0 && r.sources.every((s) => s.url.startsWith('https://')), r.id);
});

const cases: [string, string][] = [
  ["g++ : The term 'g++' is not recognized as the name of a cmdlet", 'CPP-001'],
  ['#include errors detected. Please update your includePath.', 'VSC-030'],
  ["undefined reference to `add(int, int)' collect2.exe: error: ld returned 1 exit status", 'CPP-050'],
  ['Unable to start debugging. The value of miDebuggerPath is invalid', 'VSC-081'],
  ['No build task to run found', 'VSC-070'],
  ["undefined reference to `WinMain'", 'CPP-051'],
  ['running scripts is disabled on this system', 'CPP-061'],
  ['libstdc++-6.dll was not found', 'CPP-063'],
  ['structured bindings only available with -std=c++17', 'CPP-091'],
  ['code runner cin input not working', 'VSC-023']
];
for (const [q, id] of cases) {
  test(`retrieves ${id} for "${q.slice(0, 40)}"`, () => {
    const top = kb.search(q, 3);
    assert.equal(top[0]?.record.id, id, JSON.stringify(top.map((m) => [m.record.id, m.score])));
  });
}

test('match kinds', () => {
  const q = "'g++' is not recognized as an internal or external command";
  assert.equal(matchKind(kb.search(q), q, false), 'known_verified');
  const oos = 'How do I fix my python pip install for Django on my website?';
  assert.equal(matchKind(kb.search(oos), oos, false), 'out_of_scope');
});

test('classify', () => {
  assert.equal(classify('ld returned 1 exit status'), 'Linker Errors');
  assert.equal(classify('miDebuggerPath invalid'), 'Debugging');
});

test('parseDiagnosis handles fenced JSON and plain text', () => {
  const d = parseDiagnosis('```json\n{"kind":"question","question":"Which compiler?","confidence":"90%"}\n```');
  assert.equal(d.kind, 'question');
  assert.equal(d.confidence, undefined);
  assert.equal(parseDiagnosis('just text').kind, 'text');
});
