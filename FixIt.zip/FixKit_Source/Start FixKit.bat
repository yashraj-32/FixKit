@echo off
setlocal
set "APP_DIR=%~dp0"
set "ELECTRON=%APP_DIR%node_modules\electron\dist\electron.exe"
if not exist "%ELECTRON%" (
  echo First-time FixKit setup is installing its runtime and dependencies...
  where npm.cmd >nul 2>&1
  if errorlevel 1 (
    echo Node.js with npm is required for first-time setup.
    echo Install Node.js, then double-click this launcher again.
    pause
    exit /b 1
  )
  pushd "%APP_DIR%"
  call npm.cmd install
  if errorlevel 1 (
    echo FixKit setup did not complete. Check your internet connection and try again.
    popd
    pause
    exit /b 1
  )
  popd
)
if not exist "%ELECTRON%" (
  echo FixKit's Electron runtime could not be found after setup.
  pause
  exit /b 1
)
start "FixKit" "%ELECTRON%" "%APP_DIR%"
exit /b 0
