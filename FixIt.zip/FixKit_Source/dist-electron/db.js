"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.Store = void 0;
const node_fs_1 = __importDefault(require("node:fs"));
const node_path_1 = __importDefault(require("node:path"));
const sql_js_1 = __importDefault(require("sql.js"));
// Ordered, append-only migrations. Never edit a shipped migration; add a new one.
const MIGRATIONS = [
    `CREATE TABLE sessions (
     id INTEGER PRIMARY KEY AUTOINCREMENT,
     title TEXT NOT NULL,
     category TEXT,
     status TEXT NOT NULL DEFAULT 'open',
     created_at TEXT NOT NULL,
     updated_at TEXT NOT NULL
   );
   CREATE TABLE messages (
     id INTEGER PRIMARY KEY AUTOINCREMENT,
     session_id INTEGER NOT NULL REFERENCES sessions(id) ON DELETE CASCADE,
     role TEXT NOT NULL,
     content TEXT NOT NULL,
     diagnosis TEXT,
     images TEXT NOT NULL DEFAULT '[]',
     meta TEXT,
     created_at TEXT NOT NULL
   );
   CREATE INDEX idx_messages_session ON messages(session_id);
   CREATE TABLE preferences (
     key TEXT PRIMARY KEY,
     value TEXT NOT NULL
   );`
];
class Store {
    dataDir;
    db;
    file;
    constructor(dataDir) {
        this.dataDir = dataDir;
        this.file = node_path_1.default.join(dataDir, 'fixkit.db');
    }
    async open(wasmPath) {
        const SQL = await (0, sql_js_1.default)(wasmPath ? { locateFile: () => wasmPath } : undefined);
        node_fs_1.default.mkdirSync(this.dataDir, { recursive: true });
        this.db = node_fs_1.default.existsSync(this.file) ? new SQL.Database(node_fs_1.default.readFileSync(this.file)) : new SQL.Database();
        this.db.run('PRAGMA foreign_keys = ON');
        this.migrate();
    }
    migrate() {
        this.db.run('CREATE TABLE IF NOT EXISTS schema_version (version INTEGER NOT NULL)');
        const row = this.one('SELECT version FROM schema_version');
        let version = row?.version ?? 0;
        if (!row)
            this.db.run('INSERT INTO schema_version (version) VALUES (0)');
        while (version < MIGRATIONS.length) {
            this.db.exec(MIGRATIONS[version]);
            version++;
            this.db.run('UPDATE schema_version SET version = ?', [version]);
        }
        this.persist();
    }
    persist() {
        const tmp = this.file + '.tmp';
        node_fs_1.default.writeFileSync(tmp, Buffer.from(this.db.export()));
        node_fs_1.default.renameSync(tmp, this.file);
    }
    all(sql, params = []) {
        const stmt = this.db.prepare(sql);
        stmt.bind(params);
        const out = [];
        while (stmt.step())
            out.push(stmt.getAsObject());
        stmt.free();
        return out;
    }
    one(sql, params = []) {
        return this.all(sql, params)[0];
    }
    lastId() {
        return this.one('SELECT last_insert_rowid() AS id').id;
    }
    // ---- sessions ----
    listSessions() {
        return this.all(`SELECT s.*, (SELECT COUNT(*) FROM messages m WHERE m.session_id = s.id) AS message_count
       FROM sessions s ORDER BY s.updated_at DESC`);
    }
    getSession(id) {
        return this.one('SELECT * FROM sessions WHERE id = ?', [id]);
    }
    createSession(title) {
        const now = new Date().toISOString();
        this.db.run('INSERT INTO sessions (title, created_at, updated_at) VALUES (?, ?, ?)', [title, now, now]);
        const id = this.lastId();
        this.persist();
        return this.getSession(id);
    }
    updateSession(id, patch) {
        const fields = Object.keys(patch);
        if (fields.length) {
            const sets = fields.map((f) => `${f} = ?`).join(', ');
            this.db.run(`UPDATE sessions SET ${sets}, updated_at = ? WHERE id = ?`, [
                ...fields.map((f) => (patch[f] ?? null)),
                new Date().toISOString(),
                id
            ]);
            this.persist();
        }
        return this.getSession(id);
    }
    deleteSession(id) {
        const images = this.getMessages(id).flatMap((m) => m.images);
        this.db.run('DELETE FROM messages WHERE session_id = ?', [id]);
        this.db.run('DELETE FROM sessions WHERE id = ?', [id]);
        this.persist();
        return images;
    }
    // ---- messages ----
    getMessages(sessionId) {
        return this.all('SELECT * FROM messages WHERE session_id = ? ORDER BY id', [sessionId]).map((r) => ({
            ...r,
            diagnosis: r.diagnosis ? JSON.parse(r.diagnosis) : null,
            images: JSON.parse(r.images),
            meta: r.meta ? JSON.parse(r.meta) : null
        }));
    }
    addMessage(m) {
        const now = new Date().toISOString();
        this.db.run('INSERT INTO messages (session_id, role, content, diagnosis, images, meta, created_at) VALUES (?, ?, ?, ?, ?, ?, ?)', [
            m.session_id,
            m.role,
            m.content,
            m.diagnosis ? JSON.stringify(m.diagnosis) : null,
            JSON.stringify(m.images),
            m.meta ? JSON.stringify(m.meta) : null,
            now
        ]);
        const id = this.lastId();
        this.db.run('UPDATE sessions SET updated_at = ? WHERE id = ?', [now, m.session_id]);
        this.persist();
        return { ...m, id, created_at: now };
    }
    // ---- preferences (never secrets) ----
    getPref(key) {
        return this.one('SELECT value FROM preferences WHERE key = ?', [key])?.value;
    }
    setPref(key, value) {
        this.db.run('INSERT INTO preferences (key, value) VALUES (?, ?) ON CONFLICT(key) DO UPDATE SET value = excluded.value', [key, value]);
        this.persist();
    }
}
exports.Store = Store;
