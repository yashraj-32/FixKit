"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const node_test_1 = require("node:test");
const strict_1 = __importDefault(require("node:assert/strict"));
const node_path_1 = __importDefault(require("node:path"));
const kb_1 = require("../kb");
const engine_1 = require("../engine");
const kb = new kb_1.KnowledgeBase([node_path_1.default.join(__dirname, '..', '..', 'knowledge')]);
kb.load();
(0, node_test_1.test)('loads at least 50 records with unique ids and sources', () => {
    strict_1.default.ok(kb.records.length >= 50);
    strict_1.default.equal(new Set(kb.records.map((r) => r.id)).size, kb.records.length);
    for (const r of kb.records)
        strict_1.default.ok(r.sources.length > 0 && r.sources.every((s) => s.url.startsWith('https://')), r.id);
});
const cases = [
    ["g++ : The term 'g++' is not recognized as the name of a cmdlet", 'CPP-001'],
    ['#include errors detected. Please update your includePath.', 'VSC-030'],
    ["undefined reference to `add(int, int)' collect2.exe: error: ld returned 1 exit status", 'CPP-050'],
    ['Unable to start debugging. The value of miDebuggerPath is invalid', 'VSC-081'],
    ['No build task to run found', 'VSC-070'],
    ["undefined reference to `WinMain'", 'CPP-051'],
    ['running scripts is disabled on this system', 'CPP-061'],
    ['libstdc++-6.dll was not found', 'CPP-063'],
    ['structured bindings only available with -std=c++17', 'CPP-091'],
    ['code runner cin input not working', 'VSC-023']
];
for (const [q, id] of cases) {
    (0, node_test_1.test)(`retrieves ${id} for "${q.slice(0, 40)}"`, () => {
        const top = kb.search(q, 3);
        strict_1.default.equal(top[0]?.record.id, id, JSON.stringify(top.map((m) => [m.record.id, m.score])));
    });
}
(0, node_test_1.test)('match kinds', () => {
    const q = "'g++' is not recognized as an internal or external command";
    strict_1.default.equal((0, kb_1.matchKind)(kb.search(q), q, false), 'known_verified');
    const oos = 'How do I fix my python pip install for Django on my website?';
    strict_1.default.equal((0, kb_1.matchKind)(kb.search(oos), oos, false), 'out_of_scope');
});
(0, node_test_1.test)('classify', () => {
    strict_1.default.equal((0, kb_1.classify)('ld returned 1 exit status'), 'Linker Errors');
    strict_1.default.equal((0, kb_1.classify)('miDebuggerPath invalid'), 'Debugging');
});
(0, node_test_1.test)('parseDiagnosis handles fenced JSON and plain text', () => {
    const d = (0, engine_1.parseDiagnosis)('```json\n{"kind":"question","question":"Which compiler?","confidence":"90%"}\n```');
    strict_1.default.equal(d.kind, 'question');
    strict_1.default.equal(d.confidence, undefined);
    strict_1.default.equal((0, engine_1.parseDiagnosis)('just text').kind, 'text');
});
