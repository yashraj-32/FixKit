"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.SecretStore = void 0;
const node_fs_1 = __importDefault(require("node:fs"));
const node_path_1 = __importDefault(require("node:path"));
const electron_1 = require("electron");
/**
 * Stores the OpenRouter key encrypted with Electron safeStorage, which uses
 * Windows DPAPI (tied to the current Windows user account). The key never
 * goes into SQLite and is never sent to the renderer.
 */
class SecretStore {
    file;
    constructor(dataDir) {
        this.file = node_path_1.default.join(dataDir, 'credentials.bin');
    }
    available() {
        return electron_1.safeStorage.isEncryptionAvailable();
    }
    get() {
        // Environment variable wins, useful for development.
        if (process.env.OPENROUTER_API_KEY)
            return process.env.OPENROUTER_API_KEY;
        if (!node_fs_1.default.existsSync(this.file) || !this.available())
            return null;
        try {
            return electron_1.safeStorage.decryptString(node_fs_1.default.readFileSync(this.file));
        }
        catch {
            return null;
        }
    }
    set(key) {
        if (!this.available())
            throw new Error('Secure storage is not available on this system, so the key cannot be saved safely.');
        node_fs_1.default.writeFileSync(this.file, electron_1.safeStorage.encryptString(key.trim()));
    }
    clear() {
        if (node_fs_1.default.existsSync(this.file))
            node_fs_1.default.rmSync(this.file);
    }
    hint() {
        const k = this.get();
        return k ? `${k.slice(0, 6)}…${k.slice(-4)}` : null;
    }
}
exports.SecretStore = SecretStore;
