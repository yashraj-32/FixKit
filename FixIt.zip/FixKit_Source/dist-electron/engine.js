"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.TroubleshootingEngine = void 0;
exports.parseDiagnosis = parseDiagnosis;
const kb_1 = require("./kb");
const openrouter_1 = require("./openrouter");
const SYSTEM_PROMPT = `You are FixKit, a patient senior technical support engineer. You ONLY troubleshoot:
1) Visual Studio Code (installation, extensions, settings, terminal, tasks.json, launch.json, c_cpp_properties.json, IntelliSense, workspaces)
2) C++ toolchains on Windows used with VS Code (MinGW-w64, MSYS2, GCC/G++, GDB, PATH, compile/link errors, C++ standard flags).
You are not a general coding assistant. If the request is outside this scope, politely say so (kind "out_of_scope").

Your users are students and beginners on Windows. Be precise and concrete:
- Name the exact menu, button, file, and setting. Only reference VS Code UI that actually exists (e.g. "Terminal > New Terminal", "Ctrl+Shift+P > C/C++: Edit Configurations (UI)", "File > Preferences > Settings", "Run and Debug view (Ctrl+Shift+D)"). Never invent menus, settings keys, commands, or flags. If unsure, say so and ask.
- For each command say WHICH shell to use (VS Code integrated terminal with PowerShell, Command Prompt, or the MSYS2 UCRT64 terminal), what it does, and what output to expect.
- For config files give the exact path (e.g. ".vscode/tasks.json in your project folder"), say whether to replace the whole file or merge, and give the complete snippet.
- Never recommend registry edits, deleting system files, or disabling antivirus/security. Warn before anything destructive.
- Never claim you ran anything. The user runs every command themselves.

DIAGNOSTIC DISCIPLINE:
- If you cannot tell which of several causes applies, or key facts are missing (which compiler, which terminal, exact error text), ask ONE short conversational question (kind "question") instead of guessing. Do not ask for information already given in the conversation or visible in a screenshot.
- If a screenshot is attached, first extract what it actually shows (error text, file paths, compiler names, warnings) into screenshot_findings. Do not assume it shows more than it does.
- Prefer the documented knowledge-base records provided. If you rely on them set basis "knowledge_base" and list their ids in kb_ids. If you go beyond them use "mixed" or "general_knowledge" and say so in the cause/problem text.
- Confidence: "high" only when the error text clearly identifies the cause; "medium" when it is the most likely of a few causes; "low" otherwise. Never use percentages.

Respond with a single JSON object only, no markdown fences, matching:
{
  "kind": "diagnosis" | "question" | "out_of_scope",
  "category": string,                       // e.g. "PATH Issues", "Linker Errors"
  "title": string,                          // short headline
  "problem": string,                        // what is wrong, 1-3 sentences
  "cause": string,                          // why it happens
  "confidence": "high" | "medium" | "low",
  "basis": "knowledge_base" | "general_knowledge" | "mixed",
  "kb_ids": string[],
  "question": string,                       // required when kind is "question"; may also be a short lead-in otherwise
  "steps": [ {
      "title": string,                      // e.g. "Open a new terminal"
      "location": string,                   // where to go, e.g. "VS Code top menu bar"
      "action": string,                     // exactly what to click/type
      "code": { "language": "powershell"|"bash"|"json"|"cpp"|"text", "content": string, "where": string, "file": string, "mode": "run"|"replace"|"merge", "explanation": string },   // optional
      "expected": string                    // what the user should see
  } ],
  "verification": string,                   // how to confirm the fix worked
  "if_fails": string,                       // next diagnostic question or alternative
  "warnings": string[],
  "screenshot_findings": { "errors": string[], "paths": string[], "tools": string[], "notes": string }
}
For kind "question", steps may be empty. Use markdown sparingly inside strings (inline \`code\` is fine).`;
const GUIDANCE = {
    known_verified: 'Retrieval found one strongly matching documented record. Use it as the primary basis, adapting it to the user\'s details. Still ask a question first if a critical fact is missing.',
    known_multiple: 'Retrieval found several plausible documented records. Distinguish between them. If the conversation does not already tell you which applies, ask ONE question that discriminates between the top causes.',
    unknown: 'No documented record matched well. You may use general knowledge but set basis to "general_knowledge" and keep confidence honest. If the description is vague, ask a clarifying question.',
    out_of_scope: 'The request looks outside VS Code / C++-on-Windows troubleshooting. Unless the conversation shows otherwise, respond with kind "out_of_scope" and briefly explain what FixKit can help with.'
};
function recordForPrompt(r) {
    return {
        id: r.id,
        title: r.title,
        category: r.category,
        error: r.error,
        symptoms: r.symptoms,
        possible_causes: r.possible_causes,
        diagnostic_questions: r.diagnostic_questions,
        solution: r.solution,
        expected_result: r.expected_result,
        verification: r.verification,
        alternatives: r.alternatives,
        sources: r.sources.map((s) => s.url)
    };
}
class TroubleshootingEngine {
    kb;
    constructor(kb) {
        this.kb = kb;
    }
    retrieve(history, text, hasImage) {
        // Use recent user turns too, so follow-ups like "yes, MinGW" keep the original context.
        const userTurns = history.filter((m) => m.role === 'user').slice(-3).map((m) => m.content);
        const query = [...userTurns, text].join('\n');
        const matches = this.kb.search(query, 5);
        const kind = (0, kb_1.matchKind)(matches, query, hasImage);
        const category = (0, kb_1.classify)(query) ?? matches[0]?.record.category ?? null;
        return { matches, kind, category };
    }
    async run(input, ai) {
        const hasImage = input.images.length > 0 || input.history.some((m) => m.images.length > 0);
        const { matches, kind, category } = this.retrieve(input.history, input.text, hasImage);
        const relevant = matches.filter((m) => m.score >= 3).slice(0, 4);
        if (!ai.apiKey) {
            return { ...offlineDiagnosis(relevant, kind, category), matchKind: kind, kbIds: relevant.map((m) => m.record.id), offline: true, category };
        }
        const model = hasImage ? ai.visionModel : ai.model;
        const messages = this.buildMessages(input, relevant, kind, category);
        const raw = await (0, openrouter_1.chat)({ apiKey: ai.apiKey, model, messages, json: true });
        const diagnosis = parseDiagnosis(raw);
        return {
            diagnosis,
            category: diagnosis.category ?? category,
            matchKind: kind,
            kbIds: diagnosis.kb_ids?.length ? diagnosis.kb_ids : relevant.map((m) => m.record.id),
            model,
            offline: false
        };
    }
    buildMessages(input, relevant, kind, category) {
        const context = `RETRIEVAL RESULT: ${kind}\nGUIDANCE: ${GUIDANCE[kind]}\nRULE-BASED CATEGORY GUESS: ${category ?? 'none'}\n` +
            `DOCUMENTED KNOWLEDGE-BASE RECORDS (most relevant first):\n` +
            (relevant.length ? JSON.stringify(relevant.map((m) => recordForPrompt(m.record)), null, 1) : '(none matched)');
        const msgs = [
            { role: 'system', content: SYSTEM_PROMPT },
            { role: 'system', content: context }
        ];
        // Keep the last ~12 turns. Re-attach only the most recent prior screenshot to limit tokens.
        const recent = input.history.slice(-12);
        const lastImgMsgId = [...recent].reverse().find((m) => m.images.length)?.id;
        for (const m of recent) {
            if (m.role === 'user') {
                const parts = [{ type: 'text', text: m.content || '(screenshot only)' }];
                if (m.id === lastImgMsgId && !input.images.length) {
                    for (const name of m.images) {
                        const url = input.historyImages(name);
                        if (url)
                            parts.push({ type: 'image_url', image_url: { url } });
                    }
                }
                else if (m.images.length) {
                    parts[0] = { type: 'text', text: `${m.content}\n[${m.images.length} earlier screenshot(s) omitted]` };
                }
                msgs.push({ role: 'user', content: parts });
            }
            else if (m.role === 'assistant') {
                msgs.push({ role: 'assistant', content: m.diagnosis ? JSON.stringify(m.diagnosis) : m.content });
            }
        }
        const parts = [{ type: 'text', text: input.text || 'Please analyze the attached screenshot(s) and help me fix the problem.' }];
        for (const url of input.images)
            parts.push({ type: 'image_url', image_url: { url } });
        msgs.push({ role: 'user', content: parts });
        return msgs;
    }
}
exports.TroubleshootingEngine = TroubleshootingEngine;
function parseDiagnosis(raw) {
    const cleaned = raw.trim().replace(/^```(?:json)?\s*/i, '').replace(/```\s*$/, '');
    const start = cleaned.indexOf('{');
    const end = cleaned.lastIndexOf('}');
    if (start >= 0 && end > start) {
        try {
            const d = JSON.parse(cleaned.slice(start, end + 1));
            if (d && typeof d === 'object' && ['diagnosis', 'question', 'out_of_scope'].includes(d.kind)) {
                d.steps = Array.isArray(d.steps) ? d.steps.filter((s) => s && typeof s.action === 'string') : [];
                d.warnings = Array.isArray(d.warnings) ? d.warnings : [];
                if (!['high', 'medium', 'low'].includes(d.confidence))
                    delete d.confidence;
                return d;
            }
        }
        catch {
            /* fall through to plain text */
        }
    }
    return { kind: 'text', text: raw };
}
/** Without an API key, answer straight from the knowledge base so the app is still useful. */
function offlineDiagnosis(relevant, kind, category) {
    const top = relevant[0]?.record;
    if (kind === 'out_of_scope' || !top) {
        return {
            diagnosis: {
                kind: 'text',
                text: kind === 'out_of_scope'
                    ? 'This looks outside what FixKit covers (VS Code and C++ toolchains on Windows).'
                    : 'No documented solution in the local knowledge base matches this yet. Add your OpenRouter API key in **Settings** to get an AI diagnosis, or try describing the exact error message you see.'
            }
        };
    }
    const intro = kind === 'known_multiple'
        ? `Offline mode: several documented issues could match. Showing the closest one. Others: ${relevant
            .slice(1)
            .map((m) => `${m.record.id} (${m.record.title})`)
            .join('; ')}.`
        : 'Offline mode: showing the closest documented solution from the local knowledge base. Add an API key in Settings for a tailored diagnosis.';
    return {
        diagnosis: {
            kind: 'diagnosis',
            category: top.category ?? category ?? undefined,
            title: top.title,
            text: intro,
            problem: top.symptoms.join(' '),
            cause: 'Possible causes: ' + top.possible_causes.join('; ') + '.',
            confidence: kind === 'known_verified' ? 'medium' : 'low',
            basis: 'knowledge_base',
            kb_ids: [top.id],
            question: top.diagnostic_questions[0],
            steps: top.solution.map((s) => ({
                title: s.title,
                action: s.detail,
                location: s.file,
                code: s.code
                    ? { language: s.file?.endsWith('.json') ? 'json' : s.file ? 'text' : 'powershell', content: s.code, where: s.shell ?? s.file, file: s.file, mode: s.file ? 'replace' : 'run' }
                    : undefined
            })),
            verification: top.verification,
            if_fails: top.alternatives.join(' ')
        }
    };
}
