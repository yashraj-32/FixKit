"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const node_fs_1 = __importDefault(require("node:fs"));
const node_path_1 = __importDefault(require("node:path"));
const node_crypto_1 = __importDefault(require("node:crypto"));
const electron_1 = require("electron");
const db_1 = require("./db");
const kb_1 = require("./kb");
const engine_1 = require("./engine");
const secrets_1 = require("./secrets");
const openrouter_1 = require("./openrouter");
const DEFAULT_MODEL = 'google/gemini-2.5-flash';
const MAX_IMAGE_BYTES = 8 * 1024 * 1024;
const IMAGE_RE = /^data:image\/(png|jpe?g);base64,([A-Za-z0-9+/=]+)$/;
const dataDir = electron_1.app.getPath('userData');
const imagesDir = node_path_1.default.join(dataDir, 'screenshots');
const userKbDir = node_path_1.default.join(dataDir, 'knowledge');
const bundledKbDir = electron_1.app.isPackaged ? node_path_1.default.join(process.resourcesPath, 'knowledge') : node_path_1.default.join(__dirname, '..', 'knowledge');
const store = new db_1.Store(dataDir);
const secrets = new secrets_1.SecretStore(dataDir);
const kb = new kb_1.KnowledgeBase([bundledKbDir, userKbDir]);
const engine = new engine_1.TroubleshootingEngine(kb);
let win = null;
function settings() {
    return {
        model: store.getPref('model') ?? DEFAULT_MODEL,
        visionModel: store.getPref('visionModel') ?? DEFAULT_MODEL,
        theme: store.getPref('theme') ?? 'dark',
        hasApiKey: !!secrets.get(),
        apiKeyHint: secrets.hint(),
        secureStorage: secrets.available()
    };
}
function saveImage(a) {
    const m = IMAGE_RE.exec(a.dataUrl);
    if (!m)
        throw new Error('Only PNG and JPG screenshots are supported.');
    const buf = Buffer.from(m[2], 'base64');
    if (buf.length > MAX_IMAGE_BYTES)
        throw new Error('Screenshot is larger than 8 MB. Please crop it or save it as JPG.');
    const name = `${node_crypto_1.default.randomUUID()}.${m[1] === 'png' ? 'png' : 'jpg'}`;
    node_fs_1.default.writeFileSync(node_path_1.default.join(imagesDir, name), buf);
    return name;
}
function loadImage(name) {
    if (!/^[0-9a-f-]+\.(png|jpg)$/.test(name))
        return null; // no path traversal
    const file = node_path_1.default.join(imagesDir, name);
    if (!node_fs_1.default.existsSync(file))
        return null;
    const mime = name.endsWith('.png') ? 'image/png' : 'image/jpeg';
    return `data:${mime};base64,${node_fs_1.default.readFileSync(file).toString('base64')}`;
}
function titleFrom(text, d) {
    if (d?.title && d.kind === 'diagnosis')
        return d.title.slice(0, 80);
    const t = text.trim().replace(/\s+/g, ' ');
    return t ? (t.length > 60 ? t.slice(0, 57) + '…' : t) : 'Screenshot analysis';
}
function registerIpc() {
    electron_1.ipcMain.handle('sessions:list', () => store.listSessions());
    electron_1.ipcMain.handle('sessions:get', (_e, id) => {
        const session = store.getSession(id);
        return session ? { session, messages: store.getMessages(id) } : null;
    });
    electron_1.ipcMain.handle('sessions:create', (_e, title) => store.createSession(title || 'New session'));
    electron_1.ipcMain.handle('sessions:rename', (_e, id, title) => store.updateSession(id, { title: String(title).slice(0, 120) }));
    electron_1.ipcMain.handle('sessions:setStatus', (_e, id, status) => {
        if (!['open', 'resolved', 'unresolved'].includes(status))
            throw new Error('Invalid status');
        return store.updateSession(id, { status: status });
    });
    electron_1.ipcMain.handle('sessions:remove', (_e, id) => {
        for (const img of store.deleteSession(id))
            node_fs_1.default.rmSync(node_path_1.default.join(imagesDir, img), { force: true });
    });
    electron_1.ipcMain.handle('chat:send', async (_e, sessionId, text, attachments) => {
        text = String(text ?? '').slice(0, 20_000);
        attachments = (attachments ?? []).slice(0, 4);
        const imageNames = attachments.map(saveImage);
        const isNew = sessionId == null;
        let session = isNew ? store.createSession(titleFrom(text, null)) : store.getSession(sessionId);
        if (!session)
            throw new Error('Session not found');
        const history = store.getMessages(session.id);
        const user = store.addMessage({ session_id: session.id, role: 'user', content: text, images: imageNames, diagnosis: null, meta: null });
        const s = settings();
        let assistant;
        try {
            const out = await engine.run({ history, text, images: attachments.map((a) => a.dataUrl), historyImages: loadImage }, { apiKey: secrets.get(), model: s.model, visionModel: s.visionModel });
            assistant = store.addMessage({
                session_id: session.id,
                role: 'assistant',
                content: out.diagnosis.text ?? out.diagnosis.problem ?? out.diagnosis.question ?? '',
                diagnosis: out.diagnosis,
                images: [],
                meta: { matchKind: out.matchKind, kbIds: out.kbIds, model: out.model, offline: out.offline }
            });
            const patch = {};
            if (out.category)
                patch.category = out.category;
            if (isNew || history.length === 0)
                patch.title = titleFrom(text, out.diagnosis);
            session = store.updateSession(session.id, patch);
        }
        catch (e) {
            const message = e instanceof openrouter_1.OpenRouterError ? e.message : `Something went wrong: ${e?.message ?? e}`;
            assistant = store.addMessage({
                session_id: session.id,
                role: 'system',
                content: message,
                diagnosis: null,
                images: [],
                meta: { error: e?.code ?? 'unknown' }
            });
        }
        return { user, assistant, session };
    });
    electron_1.ipcMain.handle('kb:list', () => kb.records);
    electron_1.ipcMain.handle('kb:search', (_e, q) => kb.search(String(q), 20));
    electron_1.ipcMain.handle('kb:reload', () => kb.load());
    electron_1.ipcMain.handle('kb:openFolder', () => electron_1.shell.openPath(userKbDir));
    electron_1.ipcMain.handle('settings:get', () => settings());
    electron_1.ipcMain.handle('settings:update', (_e, patch) => {
        for (const key of ['model', 'visionModel', 'theme']) {
            const v = patch[key];
            if (typeof v === 'string' && v.trim())
                store.setPref(key, v.trim());
        }
        if (patch.theme)
            electron_1.nativeTheme.themeSource = patch.theme;
        return settings();
    });
    electron_1.ipcMain.handle('settings:setApiKey', (_e, key) => {
        if (typeof key !== 'string' || key.trim().length < 10)
            throw new Error('That does not look like an OpenRouter API key.');
        secrets.set(key);
        return settings();
    });
    electron_1.ipcMain.handle('settings:clearApiKey', () => {
        secrets.clear();
        return settings();
    });
    electron_1.ipcMain.handle('settings:test', async () => {
        const key = secrets.get();
        if (!key)
            return { ok: false, message: 'No API key saved yet.' };
        return (0, openrouter_1.testKey)(key, settings().model);
    });
    electron_1.ipcMain.handle('images:load', (_e, name) => loadImage(String(name)));
    electron_1.ipcMain.handle('app:info', () => ({
        version: electron_1.app.getVersion(),
        kbCount: kb.records.length,
        kbCategories: kb.categories(),
        kbPaths: kb.sources,
        dataDir
    }));
    electron_1.ipcMain.handle('app:openExternal', (_e, url) => {
        if (/^https:\/\//.test(url))
            return electron_1.shell.openExternal(url);
    });
}
function createWindow() {
    win = new electron_1.BrowserWindow({
        width: 1320,
        height: 860,
        minWidth: 960,
        minHeight: 640,
        backgroundColor: '#0e0f11',
        title: 'FixKit',
        autoHideMenuBar: true,
        webPreferences: {
            preload: node_path_1.default.join(__dirname, 'preload.js'),
            contextIsolation: true,
            nodeIntegration: false,
            sandbox: true
        }
    });
    // Links open in the system browser, never inside the app.
    win.webContents.setWindowOpenHandler(({ url }) => {
        if (url.startsWith('https://'))
            electron_1.shell.openExternal(url);
        return { action: 'deny' };
    });
    win.webContents.on('will-navigate', (e, url) => {
        if (!url.startsWith(process.env.VITE_DEV_SERVER_URL ?? 'file://'))
            e.preventDefault();
    });
    // Dev aid: FIXKIT_SCREENSHOT=out.png captures the first rendered frame and quits.
    const shot = process.env.FIXKIT_SCREENSHOT;
    if (shot) {
        win.webContents.on('did-finish-load', () => setTimeout(async () => {
            if (process.env.FIXKIT_SCRIPT)
                await win.webContents.executeJavaScript(process.env.FIXKIT_SCRIPT);
            setTimeout(async () => {
                node_fs_1.default.writeFileSync(shot, (await win.webContents.capturePage()).toPNG());
                electron_1.app.quit();
            }, Number(process.env.FIXKIT_WAIT ?? 800));
        }, 800));
    }
    if (process.env.VITE_DEV_SERVER_URL)
        win.loadURL(process.env.VITE_DEV_SERVER_URL);
    else
        win.loadFile(node_path_1.default.join(__dirname, '..', 'dist', 'index.html'));
}
electron_1.app.whenReady().then(async () => {
    node_fs_1.default.mkdirSync(imagesDir, { recursive: true });
    node_fs_1.default.mkdirSync(userKbDir, { recursive: true });
    const wasm = node_path_1.default.join(node_path_1.default.dirname(require.resolve('sql.js')), 'sql-wasm.wasm').replace('app.asar', 'app.asar.unpacked');
    await store.open(wasm);
    kb.load();
    electron_1.nativeTheme.themeSource = settings().theme;
    registerIpc();
    createWindow();
});
electron_1.app.on('window-all-closed', () => electron_1.app.quit());
