"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const electron_1 = require("electron");
const call = (channel) => (...args) => electron_1.ipcRenderer.invoke(channel, ...args);
const api = {
    sessions: {
        list: call('sessions:list'),
        get: call('sessions:get'),
        create: call('sessions:create'),
        rename: call('sessions:rename'),
        setStatus: call('sessions:setStatus'),
        remove: call('sessions:remove')
    },
    chat: { send: call('chat:send') },
    kb: {
        list: call('kb:list'),
        search: call('kb:search'),
        reload: call('kb:reload'),
        openFolder: call('kb:openFolder')
    },
    settings: {
        get: call('settings:get'),
        update: call('settings:update'),
        setApiKey: call('settings:setApiKey'),
        clearApiKey: call('settings:clearApiKey'),
        test: call('settings:test')
    },
    images: { load: call('images:load') },
    app: { info: call('app:info'), openExternal: call('app:openExternal') }
};
electron_1.contextBridge.exposeInMainWorld('fixkit', api);
