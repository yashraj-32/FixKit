"use strict";
// Types shared between the Electron main process and the React renderer.
// Must not import any Node or Electron modules.
Object.defineProperty(exports, "__esModule", { value: true });
